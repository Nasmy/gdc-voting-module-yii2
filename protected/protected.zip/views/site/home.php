<div class="jumbotron" style="margin-bottom: -8px">
    <h1><?= Yii::t('app', 'Welcome to GDC')?></h1>
    <p><?=Yii::t('app', 'Mange users, properties, view reports') ?></p>
</div>

