<?php

namespace app\modules\api\controllers\actions\user;

use yii\base\Action;

class Delete extends Action
{
    public function run() {
        echo 'delete';
    }
}
?>