<?php

namespace app\modules\api\controllers\actions\user;

use yii\base\Action;

class Index extends Action
{
    public function run() {
        //print_r($_GET);
//        print_r(array_keys($_GET));
//        echo 'Index';
    }
}
?>